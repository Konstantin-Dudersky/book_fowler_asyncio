username = input('Please enter a username: ')
print(f'Your username is {username}')
