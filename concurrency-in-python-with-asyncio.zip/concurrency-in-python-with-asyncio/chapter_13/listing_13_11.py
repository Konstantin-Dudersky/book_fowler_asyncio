user_input = ''

while user_input != 'quit':
    user_input = input('Enter text to echo: ')
    print(user_input)
