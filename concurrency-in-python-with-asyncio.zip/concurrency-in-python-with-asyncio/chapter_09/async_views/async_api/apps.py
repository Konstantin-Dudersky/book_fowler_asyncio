from django.apps import AppConfig


class AsyncApiConfig(AppConfig):
    name = 'async_api'
