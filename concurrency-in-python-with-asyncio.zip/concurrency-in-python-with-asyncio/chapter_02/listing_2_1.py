async def my_coroutine() -> None:
    print('Hello world!')
